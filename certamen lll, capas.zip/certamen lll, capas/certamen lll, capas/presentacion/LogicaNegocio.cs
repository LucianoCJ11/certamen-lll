﻿internal class LogicaNegocio
{
    internal void AgregarCurso(string? nombre, string? descripcion, int duracion)
    {
        // Implementación del método para agregar un curso
        throw new NotImplementedException();
    }

    internal void ListarCursos()
    {
        // Implementación del método para listar cursos
        throw new NotImplementedException();
    }
}