﻿using System;

class Programa
{
    static void Main(string[] args)
    {
        LogicaNegocio logica = new LogicaNegocio();

        while (true)
        {
            Console.WriteLine("1. Agregar Curso");
            Console.WriteLine("2. Listar Cursos");
            Console.WriteLine("3. Salir");
            Console.Write("Seleccione una opción: ");

            if (!int.TryParse(Console.ReadLine(), out int opcion))
            {
                Console.WriteLine("Por favor, ingrese un número válido.");
                continue;
            }

            switch (opcion)
            {
                case 1:
                    Console.Write("Nombre del curso: ");
                    string nombre = Console.ReadLine();
                    Console.Write("Descripción del curso: ");
                    string descripcion = Console.ReadLine();
                    Console.Write("Duración del curso (en horas): ");

                    if (!int.TryParse(Console.ReadLine(), out int duracion))
                    {
                        Console.WriteLine("Por favor, ingrese un número válido para la duración.");
                        continue;
                    }

                    try
                    {
                        logica.AgregarCurso(nombre, descripcion, duracion);
                        Console.WriteLine("Curso agregado exitosamente.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error: {ex.Message}");
                    }
                    break;

                case 2:
                    try
                    {
                        logica.ListarCursos();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error al listar cursos: {ex.Message}");
                    }
                    break;

                case 3:
                    Console.WriteLine("Saliendo...");
                    return;

                default:
                    Console.WriteLine("Opción no válida. Intente nuevamente.");
                    break;
            }
        }
    }
}