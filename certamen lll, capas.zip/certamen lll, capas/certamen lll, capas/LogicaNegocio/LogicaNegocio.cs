﻿using System;

namespace LogicaNegocio
{
    internal class LogicaNegocio
    {
        private readonly AccesoDatos accesoDatos = new AccesoDatos();

        public void AgregarCurso(string nombre, string descripcion, int duracion)
        {
            if (string.IsNullOrWhiteSpace(nombre))
            {
                throw new ArgumentException("El nombre no puede estar vacío.", nameof(nombre));
            }

            if (string.IsNullOrWhiteSpace(descripcion))
            {
                throw new ArgumentException("La descripción no puede estar vacía.", nameof(descripcion));
            }

            if (duracion <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(duracion), "La duración debe ser mayor a cero.");
            }

            accesoDatos.AgregarCurso(nombre, descripcion, duracion);
        }
    }
}