﻿using System;
using System.Data.SqlClient;

namespace LogicaNegocio
{
    public class AccesoDatos
    {
        private string conexion = "cadenita"; 

        public void AgregarCurso(string nombre, string descripcion, int duracion)
        {
            using (SqlConnection conectar = new SqlConnection(conexion))
            {
                string query = "INSERT INTO Cursos (Nombre, Descripcion, Duracion) VALUES (@Nombre, @Descripcion, @Duracion)";
                using (SqlCommand cmd = new SqlCommand(query, conectar))
                {
                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    cmd.Parameters.AddWithValue("@Descripcion", descripcion);
                    cmd.Parameters.AddWithValue("@Duracion", duracion);

                    try
                    {
                        conectar.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine($"Error al agregar el curso: {ex.Message}");
                    }
                }
            }
        }

        public void VerCursos()
        {
            using (SqlConnection conectar = new SqlConnection(conexion))
            {
                string query = "SELECT * FROM Cursos";
                using (SqlCommand cmd = new SqlCommand(query, conectar))
                {
                    try
                    {
                        conectar.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Console.WriteLine($"ID: {reader["Id"]}, Nombre: {reader["Nombre"]}, Descripción: {reader["Descripcion"]}, Duración: {reader["Duracion"]}");
                            }
                        }
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine($"Error al obtener los cursos: {ex.Message}");
                    }
                }
            }
        }
    }
}